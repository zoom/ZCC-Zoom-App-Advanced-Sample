import React from "react";

const Test = () => <div>Hello Test</div>

module.exports = Test
